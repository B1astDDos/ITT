﻿namespace HelpDesk.Models
{
    public class User
    {
        public int Id { get; set; }

        public string Login { get; set; }

        public string FullName { get; set; }

        public string Role { get; set; }
    }
}